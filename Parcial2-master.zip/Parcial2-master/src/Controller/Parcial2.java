package Controller;

import VMC.Frame;

public class Parcial2 {

    public static void main(String[] args) {
        
        Frame frame1 = new Frame();
        
        frame1.setVisible(true);
        frame1.setLocationRelativeTo(null);
        
    }
    
}
